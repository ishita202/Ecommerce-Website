export const products = [
  {
    id: 1,
    title: "Men's Cotton Shirt",
    brand: "Roadster",
    price: "₹899",
    image: "https://via.placeholder.com/200x250?text=Shirt",
  },
  {
    id: 2,
    title: "Women's Floral Dress",
    brand: "Sassafras",
    price: "₹1299",
    image: "https://via.placeholder.com/200x250?text=Dress",
  },
  {
    id: 3,
    title: "Unisex Sneakers",
    brand: "Nike",
    price: "₹2999",
    image: "https://via.placeholder.com/200x250?text=Sneakers",
  },
];
