import React from "react";
// import "./Footer.css";

const WomenClothing = () => {
  return (
    <div className="WomenClothing">
        <p>Women Clothing</p>
        </div>
  );
};

export default WomenClothing;
