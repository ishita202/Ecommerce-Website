import React from "react";
// import "./Footer.css";

const MenClothing= () => {
  return (
    <div className="MenClothing">
        <p>Men Clothing</p>
        </div>
  );
};

export default MenClothing;
